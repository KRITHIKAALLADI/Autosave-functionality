import React from 'react';
import './App.css';
import Form from './Form/Form';


function App() {
  return (
    <div className="App">
      <h1>User Form</h1>
      <Form />
    </div>
  );
}

export default App;